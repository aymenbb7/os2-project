#ifndef ASM_FUNCTIONS_H
#define ASM_FUNCTIONS_H

#include <stddef.h>
#include <stdbool.h>

unsigned int lcm_asm(unsigned int a, unsigned int b);
int array_max_asm(const int* arr, size_t length);
bool is_empty_asm(const char* str);

#endif