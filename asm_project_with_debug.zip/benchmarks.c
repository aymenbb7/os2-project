#include <stdio.h>
#include <time.h>
#include "include/asm_functions.h"

void benchmark_lcm() {
    const int iterations = 1000000;
    clock_t start, end;
    start = clock();
    for (int i = 0; i < iterations; i++) {
        lcm_asm(123, 456);
    }
    end = clock();
    printf("lcm_asm benchmark: %.4f seconds\n", (double)(end - start) / CLOCKS_PER_SEC);
}

void benchmark_array_max() {
    const int iterations = 1000000;
    int arr[] = {1, 9, 5, 3, 7, 11, 2, 6, 8, 4};
    clock_t start, end;
    start = clock();
    for (int i = 0; i < iterations; i++) {
        array_max_asm(arr, 10);
    }
    end = clock();
    printf("array_max_asm benchmark: %.4f seconds\n", (double)(end - start) / CLOCKS_PER_SEC);
}

int main() {
    benchmark_lcm();
    benchmark_array_max();
    return 0;
}