#include <stdio.h>
#include "../include/asm_functions.h"

void test_lcm() {
    printf("Testing lcm_asm...\n");
    printf("LCM(4, 6) = %u (Expected: 12)\n", lcm_asm(4, 6));
    printf("LCM(21, 6) = %u (Expected: 42)\n", lcm_asm(21, 6));
}

void test_array_max() {
    printf("Testing array_max_asm...\n");
    int arr[] = {1, 7, 3, 9, 2};
    printf("Max = %d (Expected: 9)\n", array_max_asm(arr, 5));
}

void test_is_empty() {
    printf("Testing is_empty_asm...\n");
    printf("Empty string: %s (Expected: Yes)\n", is_empty_asm("") ? "Yes" : "No");
    printf("Non-empty string: %s (Expected: No)\n", is_empty_asm("abc") ? "Yes" : "No");
}

int main() {
    test_lcm();
    test_array_max();
    test_is_empty();
    return 0;
}