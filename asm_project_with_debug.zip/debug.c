#include <stdio.h>
#include "include/asm_functions.h"

void debug_lcm() {
    unsigned int a = 15, b = 20;
    unsigned int result = lcm_asm(a, b);
    printf("[DEBUG] LCM(%u, %u) = %u\n", a, b, result);
}

void debug_array_max() {
    int arr[] = {4, 8, 2, 9, 1};
    size_t len = sizeof(arr) / sizeof(arr[0]);
    int max = array_max_asm(arr, len);
    printf("[DEBUG] Max in array = %d\n", max);
}

void debug_is_empty() {
    const char* empty = "";
    const char* non_empty = "debug";
    printf("[DEBUG] is_empty("") = %s\n", is_empty_asm(empty) ? "true" : "false");
    printf("[DEBUG] is_empty("debug") = %s\n", is_empty_asm(non_empty) ? "true" : "false");
}

int main() {
    debug_lcm();
    debug_array_max();
    debug_is_empty();
    return 0;
}