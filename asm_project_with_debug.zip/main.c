#include <stdio.h>
#include "include/asm_functions.h"

int main() {
    // LCM demo
    unsigned int a = 12, b = 18;
    printf("LCM of %u and %u: %u\n", a, b, lcm_asm(a, b));

    // Array max demo
    int arr[] = {5, 1, 9, 3, 7};
    size_t len = sizeof(arr) / sizeof(arr[0]);
    printf("Max in array: %d\n", array_max_asm(arr, len));

    // is_empty demo
    const char* s1 = "";
    const char* s2 = "hello";
    printf("Is empty (s1)? %s\n", is_empty_asm(s1) ? "Yes" : "No");
    printf("Is empty (s2)? %s\n", is_empty_asm(s2) ? "Yes" : "No");

    return 0;
}